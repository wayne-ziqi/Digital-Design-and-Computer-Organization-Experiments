#include "../include/sys.h"
#include "../include/filesys.h"
#include "../include/string.h"
#include "../include/common.h"
#include "../../idesys/ide.h"

static char cmdBuf[MAX_CMDLEN + 1]; //支持两行长度的指令
static int cmdLen = 0;

void init_cpu()
{
    // asm("lui sp, 0x00120"); // set stack to high address of the dmem
    // asm("addi sp, sp, -4");
    vga_init(); //显示器初始化
    key_init(); //键盘初始化
    ide_init(); //硬盘初始化
}

void cmd_proc();
void sys_hello();

void sys_mainloop()
{
    init_cpu();
    // TODO:
    //通过getchar不断从键盘读入，检测到回车暂停并将读入的结果缓存到buffer里，
    //拿着buffer进入文件处理函数，负责找函数名，将pc移动到可执行文件首地址
    //可执行文件执行完成调用ret_sys进入到getcmd()函数
    sys_hello();
    vga_init();
    while (1)
    {
        putstr("(qinux)/usr/wangzai/$");
        get_expr(cmdBuf, &cmdLen, MAX_CMDLEN + 1);
        cmd_proc();
    }
}

void cmd_proc()
{
    if (cmdLen <= 1)
        return;

    char *cmd = cmdBuf;

    if (cmd[0] == '.' && cmd[1] == '/')
    {
        char *filename = cmd + 2;
        while (*filename == ' ')
            filename++;
        file_proc((const char *)filename); //负责将pc指向待执行程序
    }
    else if (cmd[0] == 'v' && cmd[1] == 'i' && cmd[2] == ' ')
    {
        char *filename = cmd + 2;
        while (*filename == ' ')
            filename++;
        ide_proc((const char *)filename, RDWR_FILE); //创建或读写
    }
    else if (cmd[0] == 'r' && cmd[1] == 'm' && cmd[2] == ' ')
    {
        char *filename = cmd + 2;
        while (*filename == ' ')
            filename++;
        ide_proc((const char *)filename, RM_FILE); //删除
    }
    else if (cmdLen == 3 && cmd[0] == 'l' && cmd[1] == 's')
    {
        ide_proc(NULL, LS_FILES);
    }
    else if (strcmp(cmd, "man") == 0)
    {
        print_man();
    }
    else if (strcmp(cmd, "clear") == 0)
    {
        vga_init();
    }
    else if (strcmp(cmd, "time") == 0)
    {
        print_time();
    }
    else if (strcmp(cmd, "ledon") == 0)
    {
        led_on();
    }
    else if (strcmp(cmd, "ledoff") == 0)
    {
        led_off();
    }
    else
    {
        cmd_missed(cmd, CMD_MISSED);
    }
}

void sys_hello()
{
    putstr("                                                                  \n");
    putstr("                                                                  \n");
    putstr("                                                                  \n");
    putstr("      ooooooooooooo                         .oooooo.              \n");
    putstr("      8\'   888   `8                        d8P\'  `Y8b             \n");
    putstr("           888       .ooooo.  oooo  oooo  888            .ooooo.  \n");
    putstr("           888      d88\' `88b `888  `888  888           d88\' `88b \n");
    putstr("           888      888   888  888   888  888     ooooo 888ooo888 \n");
    putstr("           888      888   888  888   888  `88.    .88\'  888    .o \n");
    putstr("          o888o     `Y8bod8P\'  `V88V\"V8P\'  `Y8bood8P\'   `Y8bod8P\' \n");
    putstr("                                                              \n");
    putstr("     -------- CPU AND I/O HARDWRAE MADE BY liu hongwang :)------- \n");
    putstr("                                                                  \n");
    putstr("         .oooooo.       o8o                                       \n");
    putstr("        d8P\'  `Y8b      `\"\'                                       \n");
    putstr("       888      888    oooo  ooo. .oo.   oooo  oooo  oooo    ooo  \n");
    putstr("       888      888    `888  `888P\"Y88b  `888  `888   `88b..8P\'   \n");
    putstr("       888      888     888   888   888   888   888     Y888'     \n");
    putstr("       `88b    d88b     888   888   888   888   888   .o8\"\'88b    \n");
    putstr("        `Y8bood8P\'Ybd\' o888o o888o o888o  `V88V\"V8P\' o88\'   888o  \n");
    putstr("                                                              \n");
    putstr("     ----- KERNEL AND BUILT-IN PROGRAMS MADE BY wang ziqi :) -----\n");
    putstr("                                                                  \n");
    putstr("                                                                  \n");
    putstr("                                      (PRESS ANY KEY TO CONTINUE) \n");
    char ch = getchar();
    while (ch == 0)
    {
        ch = getchar();
    }
}