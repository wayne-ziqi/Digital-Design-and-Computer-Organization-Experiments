#include "../include/filesys.h"
#include "../include/sys.h"
#include "../include/string.h"
#include "../../testcase/testcase.h"

typedef struct File
{
    const char name[32];
    void (*entry)();
} File;

File file_table[] = {{"hello", ENTRY_hello}, {"fib", ENTRY_fib}, {"echo", ENTRY_echo}, {"expr", ENTRY_expr}}; //testcase 的入口函数

void cmd_missed(const char *name, int type) // name 可能是文件名或者指令名
{
    putstr(name);
    switch (type)
    {
    case FILE_MISSED:
        /* code */
        putstr(": file's not found\n");
        break;
    case CMD_MISSED:
        putstr(": unknown command, use \'man\' command to look up the guide.\n");
        break;
    default:
        putstr(": unknown command, use \'man\' command to look up the guide.\n");
        break;
    }
}

void file_proc(const char *filename)
{
    //对文件表进行遍历，如果找到匹配的文件名就跳转到对应样例的入口函数执行
    //找不到就调用cmd_missed函数执行
    int ind;
    for (ind = 0; ind < NR_FILES; ind++)
        if (strcmp(filename, file_table[ind].name) == 0)
            break;
    if (ind != NR_FILES)
    {
        (*(file_table[ind].entry))();
    }
    else //testcase missed
    {
        cmd_missed(filename, FILE_MISSED);
    }
}