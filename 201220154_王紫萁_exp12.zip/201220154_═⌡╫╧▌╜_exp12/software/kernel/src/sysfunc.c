#include "../include/sys.h"
#include "../include/common.h"

/********vga********/
char *vga_start = (char *)VGA_START;
int line_end[LINE_MASK];
char *last_vga_line = (char *)VGA_LINE;
char *last_vga_ch = (char *)VGA_COL;
char *out_page_start = (char *)VGA_LINE_O;
char vga_line;
char vga_ch;
char page_start;

void vga_init()
{
    vga_line = 0;
    vga_ch = 0;
    page_start = 0;
    for (int i = 0; i < LINE_MASK; i++)
    {
        line_end[i] = 0;
        for (int j = 0; j < VGA_MAXCOL; j++)
            vga_start[(i << 7) + j] = 0;
    }
}

void in_putchar(const char ch)
{
    if (ch == 8) // backspace
    {
        // TODO
        if (vga_ch > 0) //直接回退
        {
            (vga_ch)--;
            vga_start[((vga_line + page_start) << 7) + vga_ch] = 0;
            line_end[page_start + vga_line]--;
        }
        else // vga_ch == 0
        {
            if(page_start > 0)
            {
                (page_start) -- ;
                vga_ch = line_end[page_start + vga_line];
            }
            else if (vga_line > 0)
            {
                (vga_line)--;
                vga_ch = line_end[page_start + vga_line]; //只回退到最后一个字符
            }
            else // vga_line == 0
            {
                if (page_start > 0)
                {
                    (page_start)--;
                    vga_ch = line_end[page_start + vga_line];
                }
                else
                    return; // page_start == 0;
            }
        }
        return;
    }

    if (ch == 10) // enter
    {
        // TODO
        line_end[page_start + vga_line] = vga_ch;
        if (vga_line < VGA_MAXLINE - 1)
        {
            (vga_line)++;
            vga_ch = 0;
        }
        else // vga_line == VGA_MAXLINE
        {
            if (page_start < VGA_MAXLINE)
            {
                //(vga_line)--;
                vga_ch = 0;
                (page_start)++;
            }
            else
            {
                vga_init();
            }
        }
        return;
    }

    vga_start[((vga_line + page_start) << 7) + vga_ch] = ch;
    (vga_ch)++;
    line_end[vga_line + page_start] = vga_ch;
    if (vga_ch >= VGA_MAXCOL)
    {
        // TODO
        if (vga_line < VGA_MAXLINE - 1)
        {
            (vga_line)++;
            vga_ch = 0;
        }
        else
        {
            if (page_start < VGA_MAXLINE)
            {
                //(vga_line)--;
                (page_start)++;
                vga_ch = 0;
            }
            else
            {
                vga_init();
            }
        }
    }
    return;
}

void out_posinfo()
{
    *last_vga_ch = vga_ch;
    *last_vga_line = vga_line;
    *out_page_start = page_start;
}

void putchar(const char ch)
{
    in_putchar(ch);
    out_posinfo();
}

void set_cursor(const char line, const char col)
{
    vga_line = line;
    vga_ch = col;
}

void putstr(const char *str)
{
    for (const char *p = str; *p != 0; p++)
        putchar(*p);
    //fflush(stdout);
}

/********key board*******/
char *pkeyhead = (char *)KEY_HEAD;             //头指针
const char *pkeytail = (const char *)KEY_TAIL; //尾指针
char *keystart = (char *)KEY_START;

void key_init()
{
    *pkeyhead = 0;
}

char getchar()
{
    if (*pkeyhead == *pkeytail)
        return 0;
    else
    {
        char c;
        c = keystart[(int)(*pkeyhead)];
        *pkeyhead = (*pkeyhead + 1) & 0x1f; //取模 %32
        return c;
    }
}

/********memory********/

void *memcpy(void *dest, const void *src, int size)
{
    // assert((dest!= NULL) && (src!= NULL));
    unsigned char *pbTo = (unsigned char *)dest;
    unsigned char *pbFrom = (unsigned char *)src;
    while (size-- > 0)
    {
        *pbTo++ = *pbFrom++;
    }
    return dest;
}

void *memset(void *dest, int src, int size)
{
    unsigned char *p = dest;
    while (size--)
        *p++ = (unsigned char)src;
    return dest;
}

/********time********/
const char *time_s0 = (const char *)TIME_S_0;
const char *time_s1 = (const char *)TIME_S_1;
const char *time_m0 = (const char *)TIME_M_0;
const char *time_m1 = (const char *)TIME_M_1;
const char *time_h0 = (const char *)TIME_H_0;
const char *time_h1 = (const char *)TIME_H_1;
void print_time()
{
    putchar((const char)(*time_h1 + '0'));
    putchar((const char)(*time_h0 + '0'));
    putchar(':');
    putchar((const char)(*time_m1 + '0'));
    putchar((const char)(*time_m0 + '0'));
    putchar(':');
    putchar((const char)(*time_s1 + '0'));
    putchar((const char)(*time_s0 + '0'));
    putchar('\n');
}

/**********LED**********/
unsigned int *ledStart = (unsigned int *)LED;
void led_on()
{
    *ledStart = 0xffff;
}
void led_off()
{
    *ledStart = 0x0000;
}

/*********manual**********/

void print_man()
{
    putstr("+---------------------------------------------------------------+\n");
    putstr("| @ available commands include:                                 |\n");
    putstr("| 1. clear: clear the screen.                                   |\n");
    putstr("| 2. man: display manual                                        |\n");
    putstr("| 3. time: display the current time since power is on           |\n");
    putstr("| 4. ledon: turn on LEDS                                        |\n");
    putstr("| 5. ledoff: turn off LEDS                                      |\n");
    putstr("+---------------------------------------------------------------+\n");
    putstr("| @ available programs include:(use ./file_name command)        |\n");
    putstr("| 1. hello: display \"hello world\"                               |\n");
    putstr("| 2. echo: put in and display characters                        |\n");
    putstr("| 3. fib: input i and display the (i)th Fibonacci number        |\n");
    putstr("| 4. expr: make \"+-*/\" calculation                              |\n");
    putstr("+---------------------------------------------------------------+\n");
    putstr("| @ available file commands include:                            |\n");
    putstr("| 1. vi {file name}: create/edit a new/existing file.           |\n");
    putstr("| 2. ls: show all existing files except built-in programs.      |\n");
    putstr("| 3. rm {file name}: delete an existing file.                   |\n");
    putstr("+---------------------------------------------------------------+\n");
}

void get_expr(char *buf, int *exprLen, const int bufLimit)
{
    // memset(cmdBuf, 0, MAX_CMDLEN + 1); //no need to clean
    *exprLen = 0;
    int curLen = 0; //减少访问寄存器的次数
    char ch = getchar();
    while (ch == 0 || ch == ' ')
    {
        if (ch == ' ')
            putchar(ch);
        ch = getchar();
    }
    while (ch != 10) //回车
    {
        if (ch == 8) // backspace
        {
            if (curLen > 0)
            {
                curLen--;
                putchar(ch);
            }
            // ch = getchar();
        }
        else if (ch != 0)
        {
            if (curLen == bufLimit)
            {
                putstr("\nlength of expression is out of limit!\n");
                *exprLen = 0;
                return;
            }
            else
            {
                buf[curLen++] = ch;
                putchar(ch);
                // ch = getchar();
            }
        }
        ch = getchar();
    }
    putchar('\n');
    // remove spaces at the tail.
    while (curLen > 0 && buf[curLen - 1] == ' ')
        curLen--;
    buf[curLen++] = '\0';
    *exprLen = curLen;
}