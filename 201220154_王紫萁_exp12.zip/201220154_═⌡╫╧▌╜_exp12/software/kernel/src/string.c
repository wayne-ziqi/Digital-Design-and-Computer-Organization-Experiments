#include"../include/string.h"
#include"../include/common.h"
#include"../include/extraInstr.h"
int strcmp(const char *str1, const char *str2)
{
    if((*str1 == '\0') && (*str2 == '\0')) return 0;
    while (*str1 && *str2 && (*str1 == *str2))
    {
        str1++;
        str2++;
    }
    return *str1 - *str2;
}

int strlen(const char *s)
{
    int len = 0;
    while (*s++)
    {
        len++;
    }
    return len;
}

unsigned int stou(const char *s) {
    unsigned int res = 0;
    for (int i = 0; i < strlen(s); i++) {
        res = __mulsi3(res,10) + s[i] - '0';
    }
    return res;
}

void itoa(int num, char str[32], unsigned int i1) {
    int len = 0;
    bool neg = 0;
    if (num < 0) //保证num>0
    {
        neg = 1;
        num = -num;
    }
    if(num == 0){
        str[len++] = '0';
        str[len++] = '\0';
        return;
    }
    while (num != 0) {
        str[len++] = (char) ('0' + __umodsi3((unsigned int)num, i1));
        num = __udivsi3((unsigned int)num, i1);
    }
    if (neg) str[len++] = '-';
    for (int i = 0, j = len - 1; i < j; i++, j--) {
        char tmp = str[i];
        str[i] = str[j];
        str[j] = tmp;
    }
    str[len] = '\0';
}

