#ifndef __FILE_SYS__
#define __FILE_SYS__

#define NR_FILES 4

enum{FILE_MISSED, CMD_MISSED};

void cmd_missed(const char* name, int type);
void file_proc(const char *filename);

#endif //__FILE_SYS__