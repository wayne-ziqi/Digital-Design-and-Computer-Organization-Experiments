#ifndef __EXTRA_INSTR_H__
#define __EXTRA_INSTR_H__

unsigned int __mulsi3(unsigned int a, unsigned int b); //return a*b
unsigned int __umodsi3(unsigned int a, unsigned int b);//return a%b
unsigned int __udivsi3(unsigned int a, unsigned int b);//return a/b

#endif//__EXTRA_INSTR_H__