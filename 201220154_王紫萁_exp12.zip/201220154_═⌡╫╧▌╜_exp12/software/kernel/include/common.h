#ifndef __COMMON_H__
#define __COMMON_H__

#define NULL ((void*) 0)
#define true (1)
#define false (0)
#define SIZE_CHAR 1
#define SIZE_INT 4
#define SIZE_UINT 4
typedef char bool;
#endif//__COMMON_H__
