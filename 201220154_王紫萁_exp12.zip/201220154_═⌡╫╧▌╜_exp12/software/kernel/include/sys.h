#ifndef __SYS_H__
#define __SYS_H__

#define VGA_START 0x00200000  // vga 首地址
#define VGA_LINE_O 0x00210000 //vga起始行首地址
#define VGA_COL 0x00210001  //VGA最后一个字符列地址存放位置
#define VGA_LINE 0x00210002 //VGA最后一个字符行地址存放位置
#define VGA_MAXLINE 30     //屏幕高度
#define LINE_MASK 0x003f   //vga显存缓冲区高度
#define VGA_MAXCOL 70      //屏幕宽度
#define VGA_SIZE 8192      //vga缓存大小

//additional io from 0x00211000
#define TIME_S_0 0x00400000 //时钟s0
#define TIME_S_1 0x00400001 //时钟s1
#define TIME_M_0 0x00400002
#define TIME_M_1 0x00400003
#define TIME_H_0 0x00400004
#define TIME_H_1 0x00400005

#define LED 0x00500000 //2 bytes

#define KEY_START 0x00300000 //键盘缓冲区首地址
#define KEY_LIMIT 0x00300020 //键盘缓冲区极限（start + size + 1）
#define KEY_SIZE 0x20        //键盘缓冲区大小 
#define KEY_HEAD 0x00300021  //首指针存放位置
#define KEY_TAIL 0x00300022  //尾指针存放位置

#define MAX_CMDLEN 140

// io, memory
void key_init();
char getchar();      // get char from keyboard
void putchar(const char ch);  // print char to screen
void putstr(const char *str); // print string to screen
void set_cursor(const char line, const char col);
void *memcpy(void *dest, const void *src, int size);
void *memset(void *dest, int src, int size);
void vga_init(void);
//additional io
void print_time();
void led_on();
void led_off();
//manual
void print_man();
// get expression
void get_expr(char *buf, int *exprLen, const int bufLimit);
#endif //__SYS_H__