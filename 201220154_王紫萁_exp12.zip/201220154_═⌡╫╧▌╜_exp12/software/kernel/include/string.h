#ifndef __STRING_H__
#define __STRING_H__

int strcmp(const char *s1, const char *s2);
int strlen(const char *s);
unsigned stou(const char* s);
void itoa(int num, char str[32], unsigned int i1);



#endif //__STRING_H__