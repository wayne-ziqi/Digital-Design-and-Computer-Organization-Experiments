#include "../kernel/include/sys.h"
#include "../kernel/include/string.h"

static char buf[32];
static unsigned int number;
static int buflen;
void ENTRY_fib()
{
    buflen = 0;
    putstr("input the index of fib number: ");
    get_expr(buf, &buflen, 32);
    if (buflen == 0)
        return;
    number = stou(buf);
    int fib0 = 0, fib1 = 1;
    unsigned int cnt = number;
    int res = 0;
    while ((int)cnt >= 0)
    {
        res = fib0;
        fib0 = fib1;
        fib1 = res + fib1;
        cnt--;
    }
    itoa(res, buf, 10);
    putstr("the result is: ");
    putstr(buf);
    putchar('\n');
}
