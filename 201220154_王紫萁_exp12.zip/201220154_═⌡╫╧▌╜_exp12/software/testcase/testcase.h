#ifndef __TESTCASE_H__
#define __TESTCASE_H__

void ENTRY_hello();
void ENTRY_fib();
void ENTRY_echo();
void ENTRY_expr();

#endif//__TESTCASE_H__