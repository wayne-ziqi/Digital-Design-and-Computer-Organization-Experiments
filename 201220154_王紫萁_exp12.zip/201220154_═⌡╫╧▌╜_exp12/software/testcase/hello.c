#include "../kernel/include/sys.h"
#include"testcase.h"

static const char hello[] = "Hello World!\n";

void ENTRY_hello()
{
   putstr(hello);
}