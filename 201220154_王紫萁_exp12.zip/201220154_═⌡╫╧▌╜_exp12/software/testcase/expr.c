#include "../kernel/include/sys.h"
#include "../kernel/include/string.h"
#include "../kernel/include/common.h"
#include "../kernel/include/extraInstr.h"

//支持基本表达式运算，变量赋值
#define EXPR_MAXLEN 128
enum
{
    NUM,
    OPER
};
static char expression[EXPR_MAXLEN];
static int expLen;

typedef struct Token
{
    int type;
    char str[32];
} Token;

static Token tokens[32];

static int nr_token;

int tokenize();

int exam_op();

bool valid;

unsigned int eval(int p, int q);

void ENTRY_expr()
{
    expLen = 0;
    valid = true;
    putstr("input an expression: ");
    get_expr(expression, &expLen, EXPR_MAXLEN);
    if (expLen <= 1)
        return;
    if (exam_op() < 0 || tokenize() < 0)
        return;
    unsigned int res = eval(0, nr_token - 1);
    char str_res[32];
    itoa((int)res, str_res, 10);
    if (valid)
    {
        putstr("the result is: ");
        putstr(str_res);
        putchar('\n');
    }
}

int tokenize()
{
    nr_token = 0;
    int head = 0;
    int curLen = expLen;
    while (head < curLen - 1)
    {
        char curHead = expression[head];
        if (curHead == ' ')
            head++;
        else if (curHead == '(' ||
                 curHead == '+' ||
                 curHead == '-' ||
                 curHead == '*' ||
                 curHead == '/' ||
                 curHead == ')')
        {
            tokens[nr_token++].type = curHead;
            head++;
        }
        else if (curHead >= '0' && curHead <= '9')
        {
            int tail = head + 1;
            char curTail = expression[tail];
            while (tail < curLen && curTail >= '0' && curTail <= '9')
            {
                tail++;
                curTail = expression[tail];
            }
            if (curTail != '\0' &&
                curTail != ' ' &&
                curTail != '+' &&
                curTail != '-' &&
                curTail != '*' &&
                curTail != '/' &&
                curTail != '(' &&
                curTail != ')')
            {
                putstr("unknown expression\n");
                return -1;
            }
            else
            {
                tokens[nr_token].type = NUM;
                memcpy(tokens[nr_token].str, expression + head, tail - head);
                tokens[nr_token].str[tail - head] = '\0';
                nr_token++;
                head = tail;
            }
        }
        else
        {
            putstr("unknown expression\n");
            return -1;
        }
    }
    return 0;
}

// TODO : examine neighbouring operator
int exam_op()
{
    int head = 0;
    while (head != expLen)
    {
        char curHead = expression[head];
        int tail = head + 1;
        if (curHead == '+' || curHead == '-' || curHead == '*' || curHead == '/' || curHead == '(')
        {
            while (tail <= expLen && expression[tail] == ' ')
                tail++;
            int curTail = expression[tail];
            if (curTail == '+' || curTail == '-' || curTail == '*' || curTail == '/' || curTail == ')')
                return -1;
        }
        head = tail;
    }
    return 0;
}

static int priority(int type)
{
    if (type == '+' || type == '-')
        return 11;
    if (type == '*' || type == '/')
        return 12;
    if (type == NUM)
        return 255;
    // never reach here
    return 254;
}

static bool check_parentheses(int p, int q)
{
    if (tokens[p].type == '(' && tokens[q].type == ')')
        return true;
    int cnt = 0;
    for (; p <= q; p++)
    {
        if (tokens[p].type == '(')
            cnt++;
        else if (tokens[p].type == ')')
            cnt--;
        if (cnt < 0)
        {
            putstr("parentheses mismatch\n");
            return false;
        }
    }
    if (cnt != 0)
    {
        putstr("parentheses mismatch\n");
        return false;
    }
    return false;
}

static int getDominPos(int p, int q)
{
    int pos = q;
    for (int i = q; i >= p; i--)
    { // operators having the same priority should be calculated from right to left
        if (tokens[i].type == ')')
        {
            int cnt_r = 0;
            while (i >= p)
            {
                if (tokens[i].type == ')')
                    cnt_r++;
                else if (tokens[i].type == '(')
                    cnt_r--;
                if (cnt_r == 0)
                    break;
                i--;
            }
            if (cnt_r != 0)
            {
                putstr("parentheses mismatch\n");
                return -1;
            }
        }
        pos = priority(tokens[pos].type) <= priority(tokens[i].type) ? pos : i;
    }
    // assert(pos < q);
    return pos;
}

unsigned int eval(int p, int q)
{
    // printf("p = %d, q = %d\n", p,q);
    int res = 0;
    if (p > q)
    {
        putstr("bad expression\n");
        return -1;
    }
    else if (p == q)
    {
        res = stou(tokens[p].str);
        // printf("res = %u\n", res);
        return res;
    }
    else if (check_parentheses(p, q) == true)
    {
        res = eval(p + 1, q - 1);
    }
    else
    {
        int op = getDominPos(p, q); //得到最低优先级下标
        unsigned int val1 = eval(p, op - 1);
        unsigned int val2 = eval(op + 1, q);
        switch (tokens[op].type)
        {
        case '+':
            return val1 + val2;
        case '-':
            return val1 - val2;
        case '*':
            return __mulsi3(val1, val2);
        case '/':
            return __udivsi3(val1, val2);
        default:
        {
            valid = false;
            putstr("error evaluatation, result stands no meaning\n");
        }
        }
    }
    return res;
}
