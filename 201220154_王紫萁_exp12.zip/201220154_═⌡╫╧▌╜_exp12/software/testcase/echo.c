#include "../kernel/include/sys.h"

void ENTRY_echo(){
    char ch = getchar();
    while(ch != 3){// ctrl+c
        if(ch != 0)
            putchar(ch);
        ch = getchar();
    }
    putchar('\n');
}