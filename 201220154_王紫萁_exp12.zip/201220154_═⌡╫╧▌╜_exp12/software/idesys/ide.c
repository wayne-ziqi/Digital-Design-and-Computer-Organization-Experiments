#include "StaticLink.h"
#include "../kernel/include/sys.h"
#include "../kernel/include/common.h"
#include "../kernel/include/string.h"

char *ide_start = (char *)IDE_START;

void ide_init()
{
    initList();
}

FILE_STATE *create_file(const char *filename)
{
    return addNode(filename);
}

FILE_STATE *delete_file(const char *filename)
{
    return deleteNode(filename);
}

void display_files()
{
    showFiles();
}

void do_file(FILE_STATE *p_file) { //先从磁盘搬入显存，再将读到的字符读到文件尾部
    int offset = p_file->offset;
    int tail = p_file->tail;
    vga_init();
    putstr("open file \"");
    putstr(p_file->name);
    putstr("\" successfully!\n");
    putstr("==================================================================\n");
    for (int i = 0; i < tail; i++) {
        putchar(ide_start[offset + i]);
    }
    char ch = getchar();
    while (ch != 17) // ctrl + q
    {
        if (ch != 0) {
            if (ch == 8) // backspace
            {
                if (p_file->tail > 0) {
                    ide_start[offset + p_file->tail] = 0;
                    p_file->tail--;
                    putchar(ch);
                }
            } else {
                if (p_file->tail < FILE_SIZE - 1) {
                    ide_start[offset + p_file->tail] = ch;
                    p_file->tail++;
                    putchar(ch);
                }
            }
        }
        ch = getchar();
    }
    putchar('\n');
}

void ide_proc(const char *filename, int type) {
    switch (type) {
        case RDWR_FILE: {
            FILE_STATE *p_file = searchNode(filename);
            if (p_file == NULL) {
                p_file = create_file(filename);
                if (p_file == NULL) {
                    putstr("Oops, hard disk is full.\n");
                    return;
                }
                memset(ide_start + p_file->offset, 0, FILE_SIZE); //清空磁盘
            }
            do_file(p_file);

            break;
        }

        case RM_FILE: {
            FILE_STATE *p_file = delete_file(filename);
            if (p_file == NULL) {
                putstr("file \" ");
                putstr(filename);
                putstr(" \" doesn\'t exist.\n");
            } else {
                putstr("delete file \" ");
                putstr(filename);
                putstr(" \" successfully\n");
            }
            break;
        }
        case LS_FILES: {
            display_files();
            break;
        }
    }
}
