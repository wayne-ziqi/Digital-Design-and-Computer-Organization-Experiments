#include "StaticLink.h"
#include "../kernel/include/sys.h"
#include "../kernel/include/common.h"
#include "../kernel/include/extraInstr.h"
#include "../kernel/include/string.h"

static LinkNode fileTab[MAX_NRFILES];
static int avil;

static int nr_files;

void initList()
{
    fileTab[0].link = -1;
    avil = 1;
    for (int i = 1; i < MAX_NRFILES - 1; i++)
        fileTab[i].link = i + 1;
    fileTab[MAX_NRFILES - 1].link = -1;
    nr_files = 0;
}

FILE_STATE *searchNode(const char *filename)
{
    int p = fileTab[0].link;
    while (p != -1)
    {
        if (strcmp(fileTab[p].file.name, filename) == 0)
            break;
        p = fileTab[p].link;
    }
    return (p == -1) ? NULL : &fileTab[p].file;
}

int get_file_offset(const char *filename)
{
    FILE_STATE *p_file = searchNode(filename);
    if (p_file == NULL)
        return -1;
    else
        return p_file->offset;
}

FILE_STATE *addNode(const char *filename) //返回插入后在磁盘中的位置，插入失败返回-1
{
    if (avil == -1)
        return NULL;
    int q = avil;
    avil = fileTab[avil].link;
    fileTab[q].file.tail = 0;
    fileTab[q].file.offset = __mulsi3(q, FILE_SIZE);

    int namelen = strlen(filename);
    memcpy(fileTab[q].file.name, filename, namelen);
    fileTab[q].file.name[namelen++] = '\0';
    fileTab[q].link = -1;
    int p = 0;
    while (fileTab[p].link != -1)
        p = fileTab[p].link;
    fileTab[p].link = q;

    nr_files++;

    return &fileTab[q].file;
}

FILE_STATE* deleteNode(const char *filename)
{
    if (fileTab[0].link == -1)
        return NULL; //链表为空
    bool found = false;
    int pre = 0;
    int cur = fileTab[pre].link;
    while (cur != -1)
    {
        if (strcmp(fileTab[cur].file.name, filename) == 0)
        {
            found = true;
            break;
        }
        else
        {
            pre = cur;
            cur = fileTab[cur].link;
        }
    }
    if (found)
    {
        int q = fileTab[pre].link;
        fileTab[pre].link = fileTab[q].link;
        fileTab[q].link = avil;
        avil = q;

        nr_files--;
        return &fileTab[q].file;//只有name有效
    }
    else
        return NULL;
}

void showFiles()
{
    if (fileTab[0].link == -1)
        putstr("Current Dictionary is Empty\n");
    else
    {
        int cnt = 0;
        int p = fileTab[0].link;
        while (p != -1)
        {
            putstr(fileTab[p].file.name);
            putchar(':');
            char fsize[32];
            itoa(fileTab[p].file.tail,fsize,10);
            putstr(fsize);
            putchar('B');
            if (cnt != 4)
            {
                putstr("    ");
                cnt++;
            }
            else
            {
                putchar('\n');
                cnt = 0;
            }
            p = fileTab[p].link;
        }
    }
    putchar('\n');
}
