#ifndef __IDE_H__
#define __IDE_H__

#define IDE_START 0x00600000
#define MAX_NRFILES 20
#define FILE_SIZE 2100
#define MAX_VICMD_LEN 32

//extern char *ide_start;

enum{RDWR_FILE, RM_FILE, LS_FILES};
void ide_proc(const char* filename, int type);
void ide_init();

typedef struct FILE_STATE
{
    char name[32];
    int tail;
    int offset;

} FILE_STATE;

#endif//__IDE_H__