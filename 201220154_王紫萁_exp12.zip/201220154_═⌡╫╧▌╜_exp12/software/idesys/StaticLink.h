#ifndef __LINK_H__
#define __LINK_H__

#include "ide.h"
typedef struct LinkNode
{
    FILE_STATE file;
    int link;
} LinkNode;

void initList();
FILE_STATE *searchNode(const char *filename);
FILE_STATE *addNode(const char *filename);
FILE_STATE *deleteNode(const char *filename);
int get_file_offset(const char *filename);
void showFiles();
#endif //__LINK_H__